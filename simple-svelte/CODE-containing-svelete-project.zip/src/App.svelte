<script>
  import User from './lib/User.svelte'
</script>

<main>
  <div class="card">
    <User />
  </div>
</main>
